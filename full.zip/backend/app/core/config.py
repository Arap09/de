from pydantic_settings import BaseSettings
class Settings(BaseSettings): pass
settings=Settings()
